<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <title>Admin</title>
</head>
<body>
    <h1 class="text-primary text-center">Xóa vật liệu</h1>

        <?php
             $con = mysqli_connect("localhost","root","","csdl");
   
    
             if(isset($_GET['id_danhmuc']) && !empty($_GET['id_danhmuc'])){
        
                    $query="DELETE FROM `danhmuc` WHERE `id_danhmuc`=".$_GET['id_danhmuc'];
                    mysqli_query($con,$query);
               header("Location: index.php");    
            } 
           mysqli_close($con);
        ?>
       
</body>
</html>