<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <title>Admin</title>
</head>
<body>
    <?php 
    $con = mysqli_connect("localhost","root","","csdl");
   
    
     if(isset($_GET['action']) && $_GET['action']=='edit'){

            $query="UPDATE `danhmuc` SET `tendanhmuc`='".$_POST['tendanhmuc']."',`soluong`='".$_POST['soluong']."',`giatien`='".$_POST['giatien']."',`img`='".$_FILES['img']['name']."' WHERE `danhmuc`.`id_danhmuc`='".$_POST['id_danhmuc']."';";
            mysqli_query($con,$query);
       header("Location: index.php");
        
    }   
    $danhmuc = mysqli_query($con,"SELECT * From danhmuc where `id_danhmuc` =".$_GET['id_danhmuc']);
    $dm= $danhmuc->fetch_assoc();
  
    if(isset($_POST['Edit']))
    {
        if(isset($_FILES['img']))
        {
            if($_FILES['img']['error'>0])
            {
                echo 'File Bi Loi';
            }
            else{

                move_uploaded_file($_FILES['img']['tmp_name'],'../images/'.$_FILES['img']['name']);

            }
        }
    }
    mysqli_close($con);
    ?>
    <div id="edit_product" class="form-group">
        <h1 class="text-primary text-center">Sửa thông tin </h1>
        <form action="./edit_product.php?action=edit" method="Post"  enctype="multipart/form-data">
            <input type="hidden" name="id_danhmuc" value="<?= $dm['id_danhmuc']?>"/>
            <div class="form-control">
                <label>Tên danh mục</label>
                <input type="text" name="tendanhmuc" value="<?= $dm['tendanhmuc']?>"/>
            </div>    
            <div class="form-control">
                <label>Số Lượng</label>
                <input type="text" name="soluong" value="<?= $dm['soluong']?>"/>
            </div>
            <div class="form-control">
                <label>Giá Tiền</label>
                <input type="text" name="giatien" value="<?= $dm['giatien']?>"/>
            </div>
            <div class="form-control">
                
                <input type="file" name="img" />
            </div>
            <div class="form-control">
                
                <input type="submit" name="Edit" value="Sửa" />
            </div>

        </form>
    </div>
</body>
</html>

