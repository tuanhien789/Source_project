<?php
session_start();
$u = $_POST['username'];
$p =  $_POST['password'];
$db = mysqli_connect("localhost","root","","csdl");
$sql = "select * from users where username='$u' and password='$p'";
$rs=mysqli_query($db,$sql);
if (mysqli_num_rows($rs) > 0){
    $_SESSION['username']= $u;
    header("Location: index.php");
}else {
    echo "<h1>dang nhap that bai</h1>";
}
?>