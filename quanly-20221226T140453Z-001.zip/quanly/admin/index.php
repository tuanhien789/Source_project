<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <title>Admin</title>
</head>
<body>
    <h1 class="text-center" style="background-color: #e4892a; color: white;">ADMIN</h1>
<div class="wrapper">
        <?php
        session_start();
            if( !isset($_SESSION['username']))
            {
                include("../pages/logout.php");
            }else{ 
            include("modules/menu.php");
            include("modules/main.php");
            include("modules/adminpage.php");}
        ?>
        </div>
</body>
</html>