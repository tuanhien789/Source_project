<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Latest compiled and minified CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Latest compiled JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/styleadmin.css">
    <title>Admin</title>
</head>
<body>
    <?php 
    $con = mysqli_connect("localhost","root","","csdl");
       if(isset($_GET['action'])&& $_GET['action']=='add') {
            $query="INSERT INTO `danhmuc`(`id_danhmuc`, `tendanhmuc`, `soluong`,`giatien`,`img`,`masp`) VALUES(NULL,'".$_POST['tendanhmuc']."','".$_POST['soluong']."','".$_POST['giatien']."','".$_FILES['img']['name']."','".$_POST['masp']."')";
            mysqli_query($con,$query);
            header("Location: index.php");
       }
   
        if(isset($_FILES['img']))
        {
            if($_FILES['img']['error'>0])
            {
                echo 'File Bi Loi';
            }
            else{

                move_uploaded_file($_FILES['img']['tmp_name'],'../images/'.$_FILES['img']['name']);

            }
        }
    
    mysqli_close($con);
    ?>
    <div id="edit_product" class="form-group">
        <h1 class="text-primary text-center">Thêm Vật Liệu </h1>
        <form action="add.php?action=add" method="Post"  enctype="multipart/form-data">
            <input type="hidden" name="id_danhmuc" value=""/>
            <div class="form-control">
                <label>Tên danh mục</label>
                <input type="text" name="tendanhmuc" value="" style=" width: 65%; margin-left: 2%;"/>
            </div>    
            <div class="form-control">
                <label>Số Lượng</label>
                <input type="text" name="soluong" value="" style=" width: 65%; margin-left: 60px;"/>
            </div>
            <div class="form-control">
                <label>Giá Tiền</label>
                <input type="text" name="giatien" value="" style=" width: 65%; margin-left: 70px;"/>
            </div>
            <div class="form-control">
                <label>Loại sản phẩm</label>
                <select name="masp" style="margin-left: 23px;">
                    <option name="masp" value="1" >Thép</option>
                    <option name="masp" value="2" >Tôn</option>
                    <option name="masp" value="3" >Xi Măng</option>
                    <option name="masp" value="4" >Đá</option>
                    <option name="masp" value="5" >Gạch Ống</option>
                    <option name="masp" value="6" >Sắt</option>
                    <option name="masp" value="7" >sàn Gỗ</option>
                </select>
            </div>
            <div class="form-control">
                
                <input type="file" name="img" />
            </div>
            <div class="form-control">
                <div class= "add1">
                    <input type="submit"  value="Thêm Vật Liệu" />
                </div>
                
            </div>

        </form>
    </div>
</body>
</html>